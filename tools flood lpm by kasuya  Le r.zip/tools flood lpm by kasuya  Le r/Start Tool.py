import customtkinter as ctk
import requests
import time
import threading

ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("blue")

app = ctk.CTk()
app.title("Flood Tool | LPM, BY KASUYA LE BG VRM")
app.geometry("550x600")

# Variable pour le mode
flood_mode = ctk.StringVar(value="mot")

def envoyer():
    tokens = entry_tokens.get("1.0", "end-1c").splitlines()
    channel_id = entry_channel.get()
    phrases_input = entry_phrase.get("1.0", "end-1c").splitlines()
    repetitions = int(entry_repeat.get())
    mode = flood_mode.get()

    def flood_token(token):
        headers = {
            "Authorization": token,
            "Content-Type": "application/json"
        }

        for _ in range(repetitions):
            if mode == "mot":
                for phrase in phrases_input:
                    mots = phrase.split()
                    for mot in mots:
                        payload = {"content": mot}
                        response = requests.post(
                            f"https://discord.com/api/v9/channels/{channel_id}/messages",
                            headers=headers,
                            json=payload
                        )
                        if response.status_code != 200:
                            print(f"[{token[:10]}...] Erreur:", response.text)
                        time.sleep(0.5)
            elif mode == "phrase":
                for phrase in phrases_input:
                    payload = {"content": phrase}
                    response = requests.post(
                        f"https://discord.com/api/v9/channels/{channel_id}/messages",
                        headers=headers,
                        json=payload
                    )
                    if response.status_code != 200:
                        print(f"[{token[:10]}...] Erreur:", response.text)
                    time.sleep(0.5)

    for token in tokens:
        threading.Thread(target=flood_token, args=(token,)).start()

# UI
ctk.CTkLabel(app, text="Tokens utilisateur (1 par ligne) :").pack(pady=(10, 0))
entry_tokens = ctk.CTkTextbox(app, width=500, height=120)
entry_tokens.pack(pady=5)

ctk.CTkLabel(app, text="ID du salon :").pack(pady=(10, 0))
entry_channel = ctk.CTkEntry(app, width=300)
entry_channel.pack(pady=5)

ctk.CTkLabel(app, text="Phrases à flood (une par ligne) :").pack(pady=(10, 0))
entry_phrase = ctk.CTkTextbox(app, width=500, height=100)
entry_phrase.pack(pady=5)

ctk.CTkLabel(app, text="Répétitions :").pack(pady=(10, 0))
entry_repeat = ctk.CTkEntry(app, width=100)
entry_repeat.insert(0, "5")
entry_repeat.pack(pady=5)

# Choix du mode
ctk.CTkLabel(app, text="Mode de flood :").pack(pady=(10, 0))
ctk.CTkRadioButton(app, text="🔤 Mot par mot", variable=flood_mode, value="mot").pack()
ctk.CTkRadioButton(app, text="📝 Phrase entière", variable=flood_mode, value="phrase").pack()

ctk.CTkButton(app, text="🚀 lancer le flood", command=envoyer).pack(pady=20)

app.mainloop()